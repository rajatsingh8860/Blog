import 'package:flutter/material.dart';
import 'package:myblog/views/create_blog.dart';

class HomePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _HomePageState();
  }
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text("Flutter", style: TextStyle(fontSize: 22)),
              Text(
                "Blog",
                style: TextStyle(fontSize: 22, color: Colors.blue),
              )
            ],
          ),
          backgroundColor: Colors.transparent,
          elevation: 0.0,
        ),
        body: Container(),
        floatingActionButton:Container(
          padding: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            FloatingActionButton(child: Icon(Icons.add), onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => CreateBlog()));
            })
          ],
        )));
  }
}
